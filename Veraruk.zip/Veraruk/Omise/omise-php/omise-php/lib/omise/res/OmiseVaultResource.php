<?php

class OmiseVaultResource extends OmiseApiResource
{
    /**
     * Returns the public key.
     *
     * @return string
     */
    protected static function getResourceKey()
    {
        return parent::getResourceKey();
    }
}
