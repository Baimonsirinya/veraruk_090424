<?php
include "../connect.php";
include "sessionlogin.php";

if(isset($_GET['times_id'])) {

  $times_id = $_GET['times_id'];

      // ค้นหา patient_id จากตาราง medical_records โดยใช้ session citizen_id
      $stmt_medical = $pdo->prepare("SELECT patient_id FROM medical_records WHERE id_card = ?");
      $stmt_medical->execute([$_SESSION['citizen_id']]);
      $medical_data = $stmt_medical->fetch(PDO::FETCH_ASSOC);

    if($medical_data) {
      $patient_id = $medical_data['patient_id'];
            
    } else {
        echo "ไม่พบข้อมูลผู้ป่วย";
    }

    $stmt = $pdo->prepare("SELECT * FROM times_of_course WHERE times_id = ?");
    $stmt->execute([$times_id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    // ตรวจสอบว่าข้อมูลถูกดึงมาหรือไม่
    if($data) {
        // ถ้าข้อมูลถูกดึงมาให้แสดงค่า
?>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href=" ../css/courseorder.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  </head>
  <header>
    <?php include "Navbar_Customers.php" ; ?>
  </header>
      <body>
        <form name="checkoutForm" method="POST" action="checkout.php">
        <input type="hidden" name="times_id" id="times_id" value="<?php echo $times_id; ?>">
        <input type="hidden" name="price" id="price" value="<?php echo $data['price']; ?>">
        <input type="hidden" name="number_of_times" id="number_of_times" value="<?php echo $data['number_of_times']; ?>">
        <input type="hidden" name="patient_id" id="patient_id" value="<?php echo $patient_id ?>">
        <input type="hidden" name="course_name" id="course_name" value="<?php echo $data['course_name']; ?>">
          <h3>รายการซื้อคอร์ส</h3>
          <div class="position-text">
            <p>คุณ <?php echo $_SESSION['username']; ?>
            <p>คอร์ส : <?php echo $data['course_name']; ?>
            <p>จำนวน : <?php echo $data['number_of_times']; ?> ครั้ง
            <p>ราคา : <?php echo $data['price']; ?><br>
          </div>
          <script type="text/javascript" src="https://cdn.omise.co/omise.js"
              data-key="pkey_test_5z2d4l2p8ta82egnll0"
              data-image="https://scontent.fbkk29-6.fna.fbcdn.net/v/t39.30808-6/310585943_109866858562309_6639729745999242134_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=qIV6QjDtZREAX9MbIYi&_nc_ht=scontent.fbkk29-6.fna&oh=00_AfCjVSWsKSobIPVkDtXvuG-LjJJ12ONMjSXuHRbxkb1cXg&oe=6610A09B"
              data-frame-label="เวฬารักษ์ สหคลินิก"
              data-button-label="ชำระเงิน"
              data-submit-label="Submit"
              data-location="no"
              data-amount="<?php echo $data['price']; ?>00"
              data-currency="thb"
              data-other-payment-methods	= "promptpay,internet_banking"
              >
          </script>
          <!--the script will render <input type="hidden" name="omiseToken"> for you automatically-->
        </form>
        <!-- data-key="YOUR_PUBLIC_KEY" -->
        </body>
        </html>
<?php
    } else {
        echo "ไม่พบข้อมูลสำหรับ times_id ที่ระบุ";
    }
} else {
    echo "ไม่ได้รับ times_id มา";
}
?>
